from pathlib import Path
import hashlib, json, re, subprocess

root = Path('/tmp/t88-fifo-eintr-20261030-1H')
repo = '/home/moritz/dev/repos/ooRexx-rust-rewrite'
expected = '434d6567458248fdb804eebe9edb715a54ddb9ded650fcca994eed6c4b691e06'
assert hashlib.sha256((root/'rexx-frozen').read_bytes()).hexdigest() == expected
rows = {}
for name in ('crate-r2', 'oracle-r3'):
    directory = root/name
    d = json.loads((directory/'descriptor.json').read_text())
    assert d['status'] == 0 and d['elapsed'] < 20
    assert not (directory/'stderr').read_bytes()
    assert d['ready_hex'] == b'READY\n'.hex()
    tid = d['blocked_before_signal']['tid']
    trace = (directory/f'trace.{tid}').read_text()
    fifo = str(directory/'pipe')
    read_lines = [line for line in trace.splitlines() if re.search(r'read\(\d+<'+re.escape(fifo)+'>', line)]
    assert '"abc"' in read_lines[0]
    assert 'ERESTARTSYS' in read_lines[1]
    assert 'rt_sigreturn({mask=[]}) = -1 EINTR' in trace
    assert 'SI_TKILL' in trace
    output = (directory/'stdout').read_text()
    if name.startswith('crate'):
        assert len(read_lines) == 3 and '"Z"' in read_lines[2]
        assert d['blocked_after_eintr']['events_file_exists'] is False
        assert output == 'warm [abc]\nread [Z]\nHALT READY:\ndescription READY:\n'
        assert (directory/'events').read_text() == 'HALT READY:\n'
    else:
        assert len(read_lines) == 2
        assert len(d['events']) == 1
        assert 'ERROR:4 Interrupted system call' in output
        assert output.index('NOTREADY') < output.index('read []') < output.index('HALT ERROR:4')
    rows[name] = {'status': d['status'], 'elapsed': d['elapsed'], 'stdout': output,
                  'read_lines': read_lines, 'reading_trace': str(directory/f'trace.{tid}')}

for name in ('partial-crate-r1', 'partial-oracle-r1'):
    directory = root/name
    d = json.loads((directory/'descriptor.json').read_text())
    assert d['status'] == 0 and d['elapsed'] < 20
    assert not (directory/'stderr').read_bytes()
    tid = d['blocked_before_signal']['tid']
    trace = (directory/f'trace.{tid}').read_text()
    fifo = str(directory/'pipe')
    read_lines = [line for line in trace.splitlines() if re.search(r'read\(\d+<'+re.escape(fifo)+'>', line)]
    assert '"abc"' in read_lines[0] and '"P"' in read_lines[1] and '= 1' in read_lines[1]
    assert 'ERESTARTSYS' in read_lines[2]
    assert 'rt_sigreturn({mask=[]}) = -1 EINTR' in trace and 'SI_TKILL' in trace
    output = (directory/'stdout').read_text()
    if name == 'partial-crate-r1':
        assert len(read_lines) == 4 and '"Z"' in read_lines[3]
        assert d['blocked_after_eintr']['events_file_exists'] is False
        assert output == 'warm [abc]\nread [PZ]\nHALT READY:\ndescription READY:\n'
    else:
        assert len(read_lines) == 3 and len(d['events']) == 2
        assert 'read []\nHALT ERROR:4 Interrupted system call' in output
        assert output.index('NOTREADY') < output.index('read []')
    rows[name] = {'status': d['status'], 'elapsed': d['elapsed'], 'stdout': output,
                  'read_lines': read_lines, 'reading_trace': str(directory/f'trace.{tid}')}

live = []
for trace in root.glob('*/trace.*'):
    pid = int(trace.name.split('.')[1])
    path = Path(f'/proc/{pid}/stat')
    if path.exists():
        live.append({'pid': pid, 'stat': path.read_text()})
assert not live, live

source = {}
for path in ('rust/crates/rexx-exec/src/dispatch/stream.rs', 'rust/crates/rexx-exec/src/lines.rs',
             'rust/crates/rexx-exec/src/signal.rs'):
    result = subprocess.run(['git','show','1d8b03220:'+path], cwd=repo, capture_output=True, check=True)
    (root/('source-'+Path(path).name)).write_bytes(result.stdout)
    source[path] = hashlib.sha256(result.stdout).hexdigest()
result = {'frozen_executable_sha256': expected, 'runtime_source': '1d8b03220',
          'source_hashes': source, 'rows': rows, 'owned_trace_pids_remaining': live}
(root/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file() and p.name != 'manifest.json'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(result, indent=2))
