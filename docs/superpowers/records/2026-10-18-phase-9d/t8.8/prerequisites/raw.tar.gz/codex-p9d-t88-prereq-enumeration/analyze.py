import collections
import json
from pathlib import Path
import re

OUT = Path('/tmp/codex-p9d-t88-prereq-enumeration')
artifacts = json.loads((OUT / 'artifacts.json').read_text())
targets = []
tests = []
failures = []
for index, artifact in enumerate(artifacts):
    name = f'target-{index:03}-{artifact["target"]["name"]}'
    record_path = OUT / (name + '.json')
    if not record_path.exists():
        continue
    record = json.loads(record_path.read_text())
    stdout = (OUT / (name + '.stdout')).read_text(errors='replace')
    stderr = (OUT / (name + '.stderr')).read_text(errors='replace')
    listed = (OUT / (name + '-list.stdout')).read_text(errors='replace')
    test_names = [line[:-6] for line in listed.splitlines() if line.endswith(': test')]
    summary_match = re.search(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout, re.M)
    summary = dict(zip(['passed', 'failed', 'ignored', 'measured', 'filtered_out'], map(int, summary_match.groups()))) if summary_match else None
    failed_names = []
    if '\nfailures:\n' in stdout:
        block = stdout.rsplit('\nfailures:\n', 1)[1].split('\ntest result:', 1)[0]
        failed_names = [line.strip() for line in block.splitlines() if line.strip()]
    explicit = dict(re.findall(r'^test (.*?) \.\.\. (ok|FAILED|ignored)(?:[^\n]*)$', stdout, re.M))
    panics = {match[0]: {'location': match[1], 'message': match[2].strip()} for match in re.findall(r"thread '([^']+)' \([^\n]+\) panicked at ([^\n]+):\n(.*?)(?=\nthread '|\Z)", stderr, re.S)}
    record.update({'package_id': artifact['package_id'], 'manifest_path': artifact['manifest_path'],
                   'target': artifact['target'], 'features': artifact['features'], 'profile': artifact['profile'],
                   'listed_tests': len(test_names), 'summary': summary,
                   'failed_names': failed_names, 'stdout_file': name + '.stdout', 'stderr_file': name + '.stderr',
                   'gate_skip_messages': [line for line in stderr.splitlines() if 'skipped without ' in line or 'skipping' in line]})
    targets.append(record)
    for test_name in test_names:
        status = 'unknown'
        evidence = 'incomplete_target'
        if test_name in failed_names:
            status, evidence = 'failed', 'completed_failure_list'
        elif test_name in explicit:
            status = {'ok': 'passed', 'FAILED': 'failed', 'ignored': 'ignored'}[explicit[test_name]]
            evidence = 'explicit_libtest_status'
        elif summary and summary['ignored'] == 0 and summary['filtered_out'] == 0:
            status, evidence = 'passed', 'completed_summary_and_failure_list'
        row = {'target_record': name, 'package_id': artifact['package_id'], 'test_name': test_name,
               'status': status, 'status_evidence': evidence}
        if status == 'failed':
            panic = panics.get(test_name, {})
            row.update(panic)
            message = panic.get('message', '')
            location = panic.get('location', '')
            if '/ootest/' in message or 'ootest' in message or ('api_group_partition.rs:397:' in location and test_name == 'a_group_whose_library_changes_changes_phase') or (name == 'target-153-concurrency_tests' and test_name in [
                'byte_exact_copies::mark_starts_keeps_a_byte_that_is_not_utf_8',
                'byte_exact_copies::skip_changes_only_the_renamed_methods_line',
                'byte_exact_copies::without_rxfuncquery_keeps_a_byte_that_is_not_utf_8']):
                row['category'] = 'missing_ootest_source'
            elif '/oodocs' in message:
                row['category'] = 'missing_oodocs_source'
            elif 'build/lib' in message or any('/rexx-api/tests/' + part in location for part in ['load.rs', 'context.rs', 'invoke.rs']) or test_name == 'scheduler::tests::callbacks::a_callback_from_another_thread_is_refused_in_the_simulation_mode':
                row['category'] = 'missing_checkout_native_artifact'
                if '/context.rs:' in location or '/load.rs:' in location or '/invoke.rs:53:' in location:
                    row['required_artifact'] = 'build/lib/librxregexp.so'
                elif '/invoke.rs:62:' in location:
                    row['required_artifact'] = 'build/lib/librxmath.so'
                else:
                    row['required_artifact'] = 'build/lib (directory)'
                    row['artifact_attribution_note'] = 'Canonicalization fails before any individual library is opened. Directory absence is the measured precondition.'
                    if test_name == 'scheduler::tests::callbacks::a_callback_from_another_thread_is_refused_in_the_simulation_mode':
                        row['cause'] = 'The immediately preceding unnamed child panics at scheduler/tests/pool.rs:239 on missing build/lib. callbacks.rs:153 calls run_shaped in that child, drops its channel sender on panic, and the named test reports Disconnected.'
            elif 'different file systems' in message:
                row['category'] = 'cross_filesystem_precondition'
            else:
                row['category'] = 'other_failure'
            failures.append(row)
        tests.append(row)

totals = collections.Counter(row['status'] for row in tests)
categories = collections.Counter(row['category'] for row in failures)
summary = {'expected_targets': len(artifacts), 'completed_targets': len(targets),
           'target_nonzero': sum(t['returncode'] != 0 for t in targets),
           'target_timeouts': sum(t['timed_out'] for t in targets),
           'test_status_counts': dict(totals), 'failure_categories': dict(categories),
           'native_artifact_counts': dict(collections.Counter(r['required_artifact'] for r in failures if 'required_artifact' in r)),
           'target_summary_totals': dict(sum((collections.Counter(t['summary']) for t in targets if t['summary']), collections.Counter())),
           'target_missing_summary': [t['name'] for t in targets if t['summary'] is None],
           'target_summary_mismatch': [t['name'] for t in targets if t['summary'] and t['listed_tests'] != sum(t['summary'].values())]}
doc_path = OUT / 'doctests.stdout'
if doc_path.exists():
    doctests = [{'test_name': name, 'status': {'ok': 'passed', 'FAILED': 'failed', 'ignored': 'ignored'}[status],
                 'mode': 'compile_fail' if name.endswith(' - compile fail') else ('compile_only' if name.endswith(' - compile') else 'executed')}
                for name, status in re.findall(r'^test (.*?) \.\.\. (ok|FAILED|ignored)[^\n]*$', doc_path.read_text(), re.M)]
    (OUT / 'doctest-results.json').write_text(json.dumps(doctests, indent=2) + '\n')
    summary['doctest_status_counts'] = dict(collections.Counter(row['status'] for row in doctests))
    summary['doctest_mode_counts'] = dict(collections.Counter(row['mode'] for row in doctests))
summary['test_target_total_elapsed_seconds'] = sum(target['elapsed_seconds'] for target in targets)
for filename, value in [('targets.json', targets), ('tests.json', tests), ('failures.json', failures), ('summary.json', summary)]:
    (OUT / filename).write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(summary, indent=2))
