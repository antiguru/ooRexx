import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/tmp/codex-p9d-t88-prereq')
OUT = Path('/tmp/codex-p9d-t88-prereq-enumeration')
OUT.mkdir(exist_ok=True)
ENV = os.environ.copy()
ENV['CARGO_INCREMENTAL'] = '0'
ENV['CARGO_TARGET_DIR'] = '/tmp/codex-p9d-t88-prereq-target'
ENV['CARGO_BUILD_JOBS'] = '4'

def run(name, args, cwd, timeout=500):
    start = time.monotonic()
    record = {'name': name, 'command': args, 'cwd': str(cwd), 'timeout_seconds': timeout,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'env_overrides': {k: ENV[k] for k in ['CARGO_INCREMENTAL', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS']}}
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        proc = subprocess.Popen(args, cwd=cwd, env=ENV, stdout=stdout, stderr=stderr, start_new_session=True)
        record['pid'] = proc.pid
        try:
            record['returncode'] = proc.wait(timeout=timeout)
            record['timed_out'] = False
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                record['returncode'] = proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                record['returncode'] = proc.wait()
    record['elapsed_seconds'] = time.monotonic() - start
    (OUT / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    return record

mode = sys.argv[1]
if mode == 'build':
    n = len(list(OUT.glob('build-*.json'))) + 1
    result = run(f'build-{n:02}', ['cargo', 'test', '--workspace', '--no-run', '--locked', '-j4', '--message-format=json'], ROOT / 'rust')
    artifacts = {}
    for path in sorted(OUT.glob('build-*.stdout')):
        for line in path.read_text(errors='replace').splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if item.get('reason') == 'compiler-artifact' and item.get('profile', {}).get('test') and item.get('executable'):
                artifacts[item['executable']] = item
    (OUT / 'artifacts.json').write_text(json.dumps(list(artifacts.values()), indent=2) + '\n')
    print(f'Collected {len(artifacts)} test executables', flush=True)
    sys.exit(0 if result['returncode'] == 0 else 1)
elif mode == 'run':
    artifacts = json.loads((OUT / 'artifacts.json').read_text())
    for i, item in enumerate(artifacts):
        name = f'target-{i:03}-{item["target"]["name"]}'
        if (OUT / (name + '.json')).exists():
            continue
        cwd = Path(item['manifest_path']).parent
        run(name + '-list', [item['executable'], '--list', '--format', 'terse'], cwd, 30)
        run(name, [item['executable'], '--test-threads=1', '--nocapture'], cwd)
elif mode == 'doc':
    run('doctests', ['cargo', 'test', '--workspace', '--doc', '--locked', '-j4', '--', '--test-threads=1'], ROOT / 'rust')
elif mode == 'verify':
    run('final-git-branch', ['git', 'branch', '--show-current'], ROOT, 30)
    run('final-git-revision', ['git', 'rev-parse', 'HEAD'], ROOT, 30)
    run('final-git-status', ['git', 'status', '--short', '--untracked-files=all'], ROOT, 30)
    run('final-git-diff', ['git', 'diff', '--exit-code'], ROOT, 30)
    run('final-git-cached-diff', ['git', 'diff', '--cached', '--exit-code'], ROOT, 30)
    run('rustc-version', ['rustc', '-Vv'], ROOT / 'rust', 30)
    run('cargo-version', ['cargo', '--version'], ROOT / 'rust', 30)
    paths = ['build/lib', 'build/lib/librxregexp.so', 'build/lib/librxmath.so',
             'build/lib/liborxmethod.so', 'build/lib/liborxfunction.so', 'build/lib/librxsock.so', 'ootest', 'oodocs']
    snapshot = {'path_exists': {path: (ROOT / path).exists() for path in paths},
                'rexx_environment': {key: value for key, value in ENV.items() if key.startswith('REXX_')},
                'filesystem_devices': {str(path): path.stat().st_dev for path in [ROOT, ROOT / 'rust/target/tmp', Path('/tmp')]}}
    (OUT / 'final-paths.json').write_text(json.dumps(snapshot, indent=2) + '\n')
    artifacts = json.loads((OUT / 'artifacts.json').read_text())
    artifact = next(item for item in artifacts if item['target']['name'] == 'rexx_exec' and item['target']['kind'] == ['lib'])
    run('callback-precondition-recheck', [artifact['executable'], '--exact',
        'scheduler::tests::callbacks::a_callback_from_another_thread_is_refused_in_the_simulation_mode',
        '--test-threads=1', '--nocapture'], Path(artifact['manifest_path']).parent, 30)
else:
    raise ValueError(mode)
