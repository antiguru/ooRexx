import collections
import json
from pathlib import Path
import shutil

OUT = Path('/tmp/codex-p9d-t88-prereq-enumeration')
summary = json.loads((OUT / 'summary.json').read_text())
targets = json.loads((OUT / 'targets.json').read_text())
tests = json.loads((OUT / 'tests.json').read_text())
failures = json.loads((OUT / 'failures.json').read_text())
lines = ['# Fresh-worktree prerequisite enumeration', '',
'''The default workspace test population at `87357a519cdac3cbfc79810dc58026d525c0c6d9` contains 99 tests blocked by absent checkout-local native paths. The run built the workspace once, executed every selected default test binary, and ran workspace doctests separately. It also found 60 missing-source failures, one filesystem precondition failure, and one unrelated stale-table failure. This is an enumeration from completed executions, not a source-search estimate.''', '',
'| Result | Count |', '| --- | ---: |',
'| Selected and completed test binaries | 154 |',
'| Binaries returning zero / nonzero | 136 / 18 |',
'| Binary tests passed / failed / ignored by existing attributes | 3603 / 161 / 5 |',
'| Native path precondition failures | 99 |',
'| Missing `ootest` source failures | 56 |',
'| Missing `oodocs` source failures | 4 |',
'| Cross-filesystem precondition failures | 1 |',
'| Unrelated stale-table failures | 1 |',
'| Doctests passed / failed | 15 / 0 |',
'| Compile errors / outer timeouts | 0 / 0 |', '',
'## Frozen source and execution scope', '',
'''Before compilation, the worktree was on `codex/p9d-t88-prereq` at the expected revision, `git status --short --untracked-files=all` was empty, and `build/lib` did not exist. The dedicated target directory `/tmp/codex-p9d-t88-prereq-target` also did not exist. Final branch, revision, status, index diff, worktree diff, and path checks confirmed the same state, with `ootest` and `oodocs` absent too. Source, index, HEAD, submodules, checkout-local native builds, and the primary worktree were not changed.''', '',
'''Outer build and test commands ran under `memcap 8G`, with `CARGO_INCREMENTAL=0`, `CARGO_BUILD_JOBS=4`, and the dedicated target directory. Cargo used `--locked` and `-j4`, and each binary ran serially in its package directory with `--test-threads=1 --nocapture`. Original build, binary, and doctest children had 500-second foreground bounds, while listing and verification children had 30-second bounds. Existing interpreter and oracle wrappers ran unchanged, and no oracle libraries were supplied as substitutes for checkout-local test artifacts.''', '',
'''Selection used Cargo JSON artifacts whose profile is a test profile and whose executable is present. All selected artifact targets have `target.test=true`, consisting of 126 integration targets, 17 binary unit harnesses, and 11 library unit harnesses, with no examples selected. All `--list` invocations succeeded, and the manifest `harness=false` settings apply only to benchmark targets outside this selection. Every selected artifact has an empty feature list, and the test profile uses optimization level 3, debug assertions, and overflow checks.''', '',
'```text',
'memcap 8G python3 /tmp/codex-p9d-t88-prereq-driver.py build',
'  cargo test --workspace --no-run --locked -j4 --message-format=json',
'memcap 8G python3 /tmp/codex-p9d-t88-prereq-driver.py run',
'  <each selected executable> --list --format terse',
'  <each selected executable> --test-threads=1 --nocapture',
'memcap 8G python3 /tmp/codex-p9d-t88-prereq-driver.py doc',
'  cargo test --workspace --doc --locked -j4 -- --test-threads=1',
'```', '',
'''The cold build completed successfully in 310.271 seconds, and binary execution took 1012.565 seconds in total. The longest binary was `collect_stress`, which passed 79 tests in 313.185 seconds, while the default corpus target passed in 151.246 seconds. All 154 binaries produced completed summaries, and their listed populations reconcile exactly with passed, failed, and ignored counts. The installed toolchain was rustc 1.99.0, recorded with full provenance in `rustc-version.stdout`.''', '',
'''No `REXX_*` variables were inherited or enabled by the driver, including corpus, ooTest, calibration, oracle-refresh, or docs-less modes. Existing tests that return early when a gate is disabled retained that behavior, so these results cover default behavior rather than full gated populations. The existing `release_local_reference` fixture test compiled its own C++ fixtures under the owned target temporary directory and passed, while the gated `outer_context` fixture construction stayed disabled. Doctests completed with four executed examples, ten compile-fail examples, and one compile-only example, with no omitted doctest target.''', '',
'The existing default ignored tests were:', '']
for row in tests:
    if row['status'] == 'ignored':
        lines.append(f'* `{row["target_record"]}::{row["test_name"]}`')
lines += ['', '## Missing checkout-local native paths', '',
'''The 99 failures below divide into 30 loader failures at explicit shared-library paths and 69 failures caused by the absent `build/lib` directory. The explicit loader paths are `build/lib/librxregexp.so` and `build/lib/librxmath.so`, whose missing loads produce the misleading `the extension publishes RexxGetPackage` panic. The directory failures happen before library loading, so the measurement does not establish that each affected test independently needs an on-disk shared object. In particular, `scheduler::tests::pool::two_native_calls_waiting_for_each_other_meet_on_pool_threads` uses a synthetic in-memory library but still reaches the shared directory canonicalization.''', '',
'| Exact missing precondition | Failed tests | Evidence |', '| --- | ---: | --- |',
'| `build/lib/librxregexp.so` | 24 | `target-016-context`, `target-063-load`, `target-066-invoke` stdout/stderr |',
'| `build/lib/librxmath.so` | 6 | `target-066-invoke` stdout/stderr |',
'| `build/lib` directory | 69 | `target-105-rexx_exec`, `target-122-sim_processes` stdout/stderr |', '',
'''The unit target accounts for 68 directory-precondition failures, and `sim_processes` accounts for the remaining one. One callback test reports `Disconnected` because its unnamed child first panics at `scheduler/tests/pool.rs:239` on the absent directory. A separate exact-test recheck reproduced that child panic and channel failure immediately, without a timeout. `callback-precondition-recheck.stdout` and `.stderr` retain this evidence rather than classifying the channel error as an unrelated failure.''', '']
for artifact in ['build/lib/librxregexp.so', 'build/lib/librxmath.so', 'build/lib (directory)']:
    lines += [f'### {artifact}', '']
    grouped = collections.defaultdict(list)
    for row in failures:
        if row.get('required_artifact') == artifact:
            grouped[row['target_record']].append(row)
    for target, rows in grouped.items():
        lines += [f'`{target}`:', '']
        lines += [f'* `{row["test_name"]}`' for row in rows]
        lines.append('')

lines += ['## Additional missing source prerequisites', '',
'''The ignored `ootest` checkout is absent, and 56 default tests fail before they can inspect their intended groups or framework copies. The missing paths include `ooRexx/base/{expressions,keyword,bif}`, `ooRexx/API`, `ooTest.frm`, and `framework/OOREXXUNIT.CLS`, with exact raw errors retained per target. The ignored `oodocs` checkout is also absent, and four extractor tests fail with an actionable SVN checkout message. No checkout was initialized, no docs-less flag was set, and failures hidden behind these missing inputs were not inferred as completed assertions.''', '']
for category, title in [('missing_ootest_source', 'Missing ootest source'), ('missing_oodocs_source', 'Missing oodocs source')]:
    lines += [f'### {title}', '']
    grouped = collections.defaultdict(list)
    for row in failures:
        if row['category'] == category:
            grouped[row['target_record']].append(row)
    for target, rows in grouped.items():
        lines += [f'`{target}`:', '']
        lines += [f'* `{row["test_name"]}`' for row in rows]
        lines.append('')

lines += ['## Separate failures', '',
'''The filesystem fixture requires its worktree temporary directory and the process temporary directory to be on different filesystems. Both directories have device ID 44 here, and the test observed a successful rename where it explicitly requires `EXDEV`. The stale refusal-site table disagrees only with committed source locations for the reported simulation refusal rows, as detailed in its raw failure output. Neither failure was repaired, retried into a pass, or counted as a missing-native-artifact failure.''', '']
for row in failures:
    if row['category'] in ['cross_filesystem_precondition', 'other_failure']:
        lines.append(f'* `{row["target_record"]}::{row["test_name"]}` at `{row.get("location", "")}`.')
lines += ['', '## Smallest common precondition proposal', '',
'''Use one documented test-entry preflight that validates checkout-local native prerequisites and exits once with their paths and the provisioning command before workspace tests start. Reuse the existing CMake targets and existing loader checks, retaining the separate oracle location and adding no Rust dependency. The shared scheduler helper should stop imposing a directory-existence requirement on synthetic-library fixtures that do not load checkout-local libraries. The gate policy in `rust/CLAUDE.md` should require this preflight without converting missing prerequisites into passing or skipped tests.''', '',
'''Source inspection after the executions identifies `rxregexp`, `rxmath`, `orxmethod`, `orxfunction`, and `rxsock` as the checkout-local library targets reached through the affected helpers. Their existing definitions are in root `CMakeLists.txt:1296`, `:1318`, `:1336`, and `testbinaries/CMakeLists.txt:64-65`. The candidate command below follows those definitions, but was not run because provisioning the missing artifacts would erase the measured fresh-checkout condition. A later implementation owner must verify that provisioning command and its actual native build prerequisites before presenting it as a proven setup recipe.''', '',
'```sh',
'memcap 8G cmake -S . -B build -DCMAKE_POLICY_VERSION_MINIMUM=3.5 -DCMAKE_BUILD_TYPE=Release',
'memcap 8G cmake --build build --target rxregexp rxmath orxmethod orxfunction rxsock -j4',
'```', '',
'## Evidence and limits', '',
'''`preflight.json` and `final-*` files record the source and path checks, while `artifacts.json` preserves Cargo selection and feature/profile metadata. `targets.json`, `tests.json`, `failures.json`, `doctest-results.json`, and `summary.json` provide machine-readable results, and each command has separate `.stdout`, `.stderr`, and `.json` files. The checked-in sources stayed frozen, and every foreground session completed, leaving no live command or enumeration blocker. These results establish the failing default population in this fresh worktree on this machine, while native leaf behavior beyond failed directory checks, missing-source downstream behavior, gated populations, other features, and other platforms remain outside the measured claim.''', '']
(OUT / 'report.md').write_text('\n'.join(lines))
for source, dest in [('/tmp/codex-p9d-t88-prereq-driver.py', 'driver.py'),
                     ('/tmp/codex-p9d-t88-prereq-analyze.py', 'analyze.py'),
                     ('/tmp/codex-p9d-t88-prereq-report.py', 'write-report.py')]:
    shutil.copyfile(source, OUT / dest)
print(OUT / 'report.md')
